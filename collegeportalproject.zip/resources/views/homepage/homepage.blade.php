<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>College Student Portal</title>
<style>
  body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
    background-color: #f2f2f2;
  }
  header {
    background-color: #35424a;
    color: white;
    text-align: center;
    padding: 10px;
  }
  .container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 20px;
  }
  .welcome-message {
    font-size: 24px;
    margin-bottom: 20px;
  }
  .featured-events {
    display: flex;
    justify-content: space-between;
    flex-wrap: wrap;
  }
  .event {
    width: calc(33.33% - 20px);
    background-color: white;
    border-radius: 5px;
    padding: 10px;
    margin-bottom: 20px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  }
  footer {
    text-align: center;
    padding: 10px;
    background-color: #35424a;
    color: white;
  }
</style>
</head>
<body>
<header>
  <h1>College Student Portal</h1>
</header>
<div class="container">
  <div class="welcome-message">
    <p>Welcome to our College Student Portal! Stay updated with the latest events and news.</p>
  </div>
  <div class="featured-events">
    <div class="event">
      <h2>Upcoming Event 1</h2>
      <p>Date: August 15, 2023</p>
      <p>Location: Campus Auditorium</p>
      <button class="register-button">Register</button>
    </div>
    <div class="event">
      <h2>Upcoming Event 2</h2>
      <p>Date: September 5, 2023</p>
      <p>Location: Student Center</p>
      <button class="register-button">Register</button>
    </div>
    <div class="event">
      <h2>Upcoming Event 3</h2>
      <p>Date: October 20, 2023</p>
      <p>Location: Sports Field</p>
      <button class="register-button">Register</button>
    </div>
  </div>
</div>
<footer>
  <p>&copy; 2023 College Student Portal</p>
</footer>

<a href="{{ route('homepage') }}">Home</a>
<a href="{{ route('course-listings') }}">Courses</a>
<a href="{{ route('contact-us') }}">Contact Us</a>



</body>
</html>
