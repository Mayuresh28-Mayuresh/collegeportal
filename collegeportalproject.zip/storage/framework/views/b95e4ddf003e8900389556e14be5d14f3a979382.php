<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Course Listings - College Student Portal</title>
<style>
  body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
    background-color: #f2f2f2;
  }
  header {
    background-color: #35424a;
    color: white;
    text-align: center;
    padding: 10px;
  }
  .container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 20px;
  }
  .course-list {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    grid-gap: 20px;
  }
  .course {
    background-color: white;
    border-radius: 5px;
    padding: 10px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  }
  footer {
    text-align: center;
    padding: 10px;
    background-color: #35424a;
    color: white;
  }
</style>
</head>
<body>
<header>
  <h1>Course Listings</h1>
</header>
<div class="container">
  <div class="course-list">
    <div class="course">
      <h2>Introduction to Computer Science</h2>
      <p>Course Code: CS101</p>
      <p>Instructor: Prof. Smith</p>
      <p>Credits: 3</p>
      <button class="enroll-button">Enroll</button>
    </div>
    <div class="course">
      <h2>Art History: Renaissance to Modern</h2>
      <p>Course Code: AH202</p>
      <p>Instructor: Prof. Johnson</p>
      <p>Credits: 4</p>
      <button class="enroll-button">Enroll</button>
    </div>
    <div class="course">
      <h2>Introduction to Psychology</h2>
      <p>Course Code: PSY101</p>
      <p>Instructor: Prof. Davis</p>
      <p>Credits: 3</p>
      <button class="enroll-button">Enroll</button>
    </div>
    <!-- Add more course listings here -->
  </div>
</div>
<footer>
  <p>&copy; 2023 College Student Portal</p>
</footer>
</body>
</html>
<?php /**PATH C:\Users\Mayuresh\Desktop\collegeportal\college-portal\resources\views/course-listings/course-listings.blade.php ENDPATH**/ ?>